package com.maxxposure.app.camera;

public interface IFocusListener {
    void focusChanged();
}
