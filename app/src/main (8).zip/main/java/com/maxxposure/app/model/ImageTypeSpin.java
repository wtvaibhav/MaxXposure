package com.maxxposure.app.model;

public class ImageTypeSpin {
    private String createdAt;

    private String workflowImageTypeSpinId;

    private String imageUrl;

    private String isStillImage;

    private String updatedAt;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getWorkflowImageTypeSpinId() {
        return workflowImageTypeSpinId;
    }

    public void setWorkflowImageTypeSpinId(String workflowImageTypeSpinId) {
        this.workflowImageTypeSpinId = workflowImageTypeSpinId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getIsStillImage() {
        return isStillImage;
    }

    public void setIsStillImage(String isStillImage) {
        this.isStillImage = isStillImage;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
