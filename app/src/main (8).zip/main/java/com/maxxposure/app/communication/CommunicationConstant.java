package com.maxxposure.app.communication;

public class CommunicationConstant {

    public static final String BASE_URL = "https://qa-admin-panel.max-xposure.co.uk/maxxposure/user/";

}

