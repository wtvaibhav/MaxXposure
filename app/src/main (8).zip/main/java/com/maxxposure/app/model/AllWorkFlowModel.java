package com.maxxposure.app.model;

import java.util.ArrayList;

public class AllWorkFlowModel {
    private ArrayList<VehicleData> vehicleData;

    public ArrayList<VehicleData> getVehicleData() {
        return vehicleData;
    }

    public void setVehicleData(ArrayList<VehicleData> vehicleData) {
        this.vehicleData = vehicleData;
    }


}