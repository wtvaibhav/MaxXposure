package com.maxxposure.app.model;

public class ImageTypeStill {
    private String createdAt;

    private String imageUrl;

    private String isStillImage;

    private String workflowImageTypeStillId;

    private String updatedAt;

    private int type;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getIsStillImage() {
        return isStillImage;
    }

    public void setIsStillImage(String isStillImage) {
        this.isStillImage = isStillImage;
    }

    public String getWorkflowImageTypeStillId() {
        return workflowImageTypeStillId;
    }

    public void setWorkflowImageTypeStillId(String workflowImageTypeStillId) {
        this.workflowImageTypeStillId = workflowImageTypeStillId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}

