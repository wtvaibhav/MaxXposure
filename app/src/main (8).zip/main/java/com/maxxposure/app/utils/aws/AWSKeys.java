package com.maxxposure.app.utils.aws;

import com.amazonaws.regions.Regions;

public class AWSKeys {

    protected static final String COGNITO_POOL_ID = "eu-west-1:ea5d0de4-7c3f-4ac7-bc95-a84c234a0bba";
    protected static final Regions MY_REGION = Regions.EU_WEST_1;
    public static final String BUCKET_NAME = "qa-dash.max-xposure.co.uk";
    public static String IMG_BASE = "https://s3-eu-west-1.amazonaws.com/qa-dash.max-xposure.co.uk/";


    /*  protected static final String COGNITO_POOL_ID = "ap-south-1:cc1802c0-754f-4c21-9c7f-4a598187d901";
      protected static final Regions MY_REGION = Regions.AP_SOUTH_1;
    public static final String BUCKET_NAME = "letsbidbucket/AuctionCards";
    public static String IMG_BASE = "https://s3-ap-south-1.amazonaws.com/letsbidbucket/AuctionCards/";*/

}
