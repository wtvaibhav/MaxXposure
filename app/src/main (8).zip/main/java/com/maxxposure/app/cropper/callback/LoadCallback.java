package com.maxxposure.app.cropper.callback;

public interface LoadCallback extends Callback {
  void onSuccess();
}
