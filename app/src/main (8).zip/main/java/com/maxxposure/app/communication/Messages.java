package com.maxxposure.app.communication;

public class Messages {

}
