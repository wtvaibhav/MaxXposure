package com.maxxposure.app.cropper.callback;

public interface Callback {
  void onError(Throwable e);
}
